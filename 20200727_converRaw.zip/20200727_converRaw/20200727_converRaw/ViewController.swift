//
//  ViewController.swift
//  20200727_converRaw
//
//  Created by Yen on 2020/7/27.
//  Copyright © 2020 Yen. All rights reserved.
//

import UIKit
import AudioKit
import Sw
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let v = Sw()
        let documentDirectory = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor:nil, create:false)
        guard let inputFileURL = documentDirectory?.appendingPathComponent("abc") else {
            return
        }
        
        guard let outputFileURL = documentDirectory?.appendingPathComponent("def.wav") else {
            return
        }
        
        v.encodeAndSaveToLocal(fileURL: inputFileURL)
//        sleep(3)
        v.decodeLocalFile(fileURL: inputFileURL)
//        self.c(oldURL: inputFileURL, newURL: outputFileURL)
//        self.convertToAudio(soundFileURL: inputFileURL)

//
//        var option = AKConverter.Options()
//        option.format = "wav"
//        let converter = AKConverter(inputURL: inputFileURL, outputURL: outputFileURL, options: option)
//        converter.start { (error) in
//            print(error)
//        }
        // Do any additional setup after loading the view.
    }
    
    func c(oldURL:URL, newURL:URL) {
        var options = AKConverter.Options()
        // any options left nil will assume the value of the input file
        options.sampleRate = 48000
        options.bitDepth = 24
        let converter = AKConverter(inputURL: oldURL, outputURL: newURL, options: options)
        converter.start(completionHandler: { error in
        // check to see if error isn't nil, otherwise you're good
        print(error)
        })
    }

    func convertToAudio(soundFileURL:URL) {
        do {
            let file = try AVAudioFile(forReading: soundFileURL)
            if let format = AVAudioFormat(commonFormat: .pcmFormatFloat64, sampleRate: file.fileFormat.sampleRate, channels: file.fileFormat.channelCount, interleaved: false), let buf = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(file.length)){
                try file.read(into: buf)
                let abl = Array(UnsafeBufferPointer(start: buf.audioBufferList, count: Int(buf.audioBufferList.pointee.mNumberBuffers)))

                let buffer = buf.audioBufferList[0].mBuffers
                let mDataList = Array(UnsafeMutableRawBufferPointer(start: buffer.mData, count: Int(buffer.mDataByteSize)))
            }
        } catch{
            print("Audio Error: \(error)")
        }
    }
}

