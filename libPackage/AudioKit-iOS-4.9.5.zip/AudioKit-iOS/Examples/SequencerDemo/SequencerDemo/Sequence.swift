//
//  Sequence.swift
//  SequencerDemo
//
//  Created by Kanstantsin Linou, revision history on Githbub.
//  Copyright © 2018 AudioKit. All rights reserved.
//

enum Sequence: Int {
    case melody = 0, bassDrum, snareDrum, snareGhost
}
