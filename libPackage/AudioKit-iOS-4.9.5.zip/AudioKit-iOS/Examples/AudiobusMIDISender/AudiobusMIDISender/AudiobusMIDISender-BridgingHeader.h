//
//  AudiobusMIDISender-BridgingHeader.h
//  AudiobusMIDISender
//
//  Created by Jeff Holtzkener on 2018/03/28.
//  Copyright © 2018 Jeff Holtzkener. All rights reserved.
//

#ifndef AudiobusMIDISender_BridgingHeader_h
#define AudiobusMIDISender_BridgingHeader_h

#import "Audiobus.h"

#endif /* AudiobusMIDISender_BridgingHeader_h */
