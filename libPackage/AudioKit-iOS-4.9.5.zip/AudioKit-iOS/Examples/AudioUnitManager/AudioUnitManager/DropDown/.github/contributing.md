### What where you trying to do

A few lines to explain the goal.

### What actually happened

A few lines to explain the bug.

### What you think went wrong (optional)

If you have an idea, don't hesitate to comment it here!

### How to reproduce the issue

Put some code here if necessary.

### Details

OS version, logs or screenshots.

Thank you for your contribution! 👍
