## Audiobus reference implementation for AudioKit

Use the included `Audiobus.swift` source file as a reference to implement Audiobus support in your iOS AudioKit applications.

The class will attempt to load an `Audiobus.txt` file containing your API key, so make sure to add it as a resource to your project.

