//
//  SenderSynth-BridgingHeader.h
//  SenderSynth
//
//  Created by Aurelius Prochazka, revision history on Githbub.
//  Copyright © 2018 AudioKit. All rights reserved.
//

#ifndef SenderSynth_BridgingHeader_h
#define SenderSynth_BridgingHeader_h

#import "Audiobus.h"

#endif /* SenderSynth_BridgingHeader_h */
