//
//  FilterEffects-BridgingHeader.h
//  FilterEffects
//
//  Created by Aurelius Prochazka, revision history on Githbub.
//  Copyright © 2018 AudioKit. All rights reserved.
//

#ifndef FilterEffects_BridgingHeader_h
#define FilterEffects_BridgingHeader_h

#import "Audiobus.h"

#endif /* FilterEffects_BridgingHeader_h */
